const menuItems = [
  ['Misal Pav','Breakfast','₹80'],['Vada Pav','Breakfast','₹25'],['Poha','Breakfast','₹40'],['Upma','Breakfast','₹45'],['Sabudana Khichdi','Breakfast','₹60'],['Thalipeeth','Breakfast','₹70'],['Batata Vada','Starter','₹45'],['Kanda Bhaji','Starter','₹60'],['Paneer Pakoda','Starter','₹120'],['Veg Manchurian Dry','Starter','₹130'],['Hara Bhara Kabab','Starter','₹140'],['Corn Cheese Balls','Starter','₹150'],['Pithla Bhakri','Lunch','₹120'],['Zunka Bhakri','Lunch','₹110'],['Maharashtrian Veg Thali','Lunch','₹180'],['Varan Bhat','Lunch','₹90'],['Masale Bhat','Lunch','₹110'],['Bharli Vangi','Lunch','₹130'],['Matki Usal','Lunch','₹100'],['Veg Kolhapuri','Dinner','₹160'],['Paneer Butter Masala','Dinner','₹190'],['Shev Bhaji','Dinner','₹140'],['Dal Tadka','Dinner','₹120'],['Dal Khichdi','Dinner','₹130'],['Jeera Rice','Dinner','₹100'],['Chapati','Dinner','₹15'],['Bhakri','Dinner','₹25'],['Puri Bhaji','Lunch','₹100'],['Pav Bhaji','Snacks','₹120'],['Dahi Misal','Snacks','₹90'],['Bhel Puri','Snacks','₹60'],['Sev Puri','Snacks','₹70'],['Samosa','Snacks','₹25'],['Veg Sandwich','Snacks','₹80'],['Masala Dosa','South Indian','₹100'],['Idli Sambar','South Indian','₹70'],['Medu Vada','South Indian','₹75'],['Uttapam','South Indian','₹100'],['Plain Tea','Tea/Coffee','₹15'],['Special Cutting Tea','Tea/Coffee','₹20'],['Masala Tea','Tea/Coffee','₹25'],['Filter Coffee','Tea/Coffee','₹35'],['Cold Coffee','Drinks','₹80'],['Lassi','Drinks','₹70'],['Fresh Lime Soda','Drinks','₹50'],['Mango Ice Cream','Ice Cream','₹60'],['Vanilla Ice Cream','Ice Cream','₹50'],['Chocolate Ice Cream','Ice Cream','₹70'],['Kulfi','Ice Cream','₹60'],['Falooda','Ice Cream','₹110']
];
const menuGrid = document.getElementById('menuGrid');
menuItems.forEach(([name, category, price]) => {
  const card = document.createElement('div');
  card.className = 'menu-card reveal';
  card.innerHTML = `<span class="category">${category}</span><h3>${name}</h3><p>Fresh and tasty Hotel Chandana special.</p><div class="price">${price}</div>`;
  menuGrid.appendChild(card);
});
function revealOnScroll(){
  document.querySelectorAll('.reveal').forEach(el=>{
    if(el.getBoundingClientRect().top < window.innerHeight - 80){el.classList.add('active')}
  })
}
window.addEventListener('scroll', revealOnScroll);
revealOnScroll();
